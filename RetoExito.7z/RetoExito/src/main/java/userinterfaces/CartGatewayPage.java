package userinterfaces;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class CartGatewayPage extends PageObject {
    public static final Target TITLE_FORM = Target.the("Show the messaje of the form").locatedBy("//*[@class='exito-checkout-io-0-x-preLoginTitle']");
    public static final Target TITLE_FORM1 = Target.the("Show the messaje of the form").locatedBy("//*[@data-molecule-product-detail-name='true']/span");
    public static final Target GO_TO_PAY = Target.the("Show the messaje of the form").locatedBy("//*[@class='exito-checkout-io-0-x-paymentButtonContentText']");
    public static final Target EMAIL_SECTION = Target.the("Show the messaje of the form").locatedBy("//*[@name='email']");
    public static final Target CONFIRM_BUTTON = Target.the("Confirm button").locatedBy("//*[@type='submit']");
    public static final Target PRODUCT_NAME = Target.the("Name of the items in the cart").locatedBy("//*[@data-molecule-product-detail-name='true']/span");
    public static final Target AMOUNT_ITEMS = Target.the("Amount of the items in the cart").locatedBy("//*[@data-molecule-quantit-und='true']/span[1]");
    public static final Target PRICE_TOTAL = Target.the("Amount of the items in the cart").locatedBy("//*[@class='exito-checkout-io-0-x-summaryTotal']/div/span[2]");

    public static final Target ITEMS_CART = Target.the("Amount ofd the items in the cart").locatedBy("//*[@data-molecule-product-detail-name='true']/span");

    public static final Target VALUE_ITEMS_CART = Target.the("Amount ofd the items in the cart").locatedBy("//*[@data-molecule-product-detail-price-best-price='true']/span");
    public static final Target UNITS_ITEMS_CART = Target.the("Amount ofd the items in the cart").locatedBy("//*[@data-molecule-quantity-und-value='true']");










}
