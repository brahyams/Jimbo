package userinterfaces;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class SubcategorieItems extends PageObject {
    public static final Target CONTAINER_OF_ITEMS = Target.the("Wrapper with specific items related").locatedBy("//article/section/div/div/h3");
    public static final Target IMAGE_ELEMET = Target.the("Wrapper with specific items related").locatedBy("//*[@data-product-card-image='true']");
    public static final Target GO_TO_CART_SECTION = Target.the("Wrapper with specific items related").locatedBy("//*[@data-fs-cart-icon-container='true']");
    public static final Target PURCHASE_BUTTON = Target.the("Wrapper with specific items related").locatedBy("//button[@class='DefaultStyle_default__vCozi ']");
    public static final Target SELECTED_ITEM = Target.the("Wrapper with specific items selected").locatedBy("//div[@class='QuantitySelectorDefault_defaultStyles__b4Srq  ']");
    public static final Target ADD_ITEMS_GENERAL = Target.the("Wrapper with specific items related").locatedBy("//div[@class='QuantitySelectorDefault_defaultStyles__b4Srq  ']/button[2]");
    public static final Target REDUCE_ITEMS_GENERAL = Target.the("Wrapper with specific items related").locatedBy("//*[@class='shelf-exito-vtex-components-buy-button-manager-reduce']");
    public static final Target QUANTITY_OF_ITEMS = Target.the("Wrapper with specific items related").locatedBy("//*[@class='exito-vtex-components-4-x-stepperContainerQty']");
    public static final Target ITEM_PRICE = Target.the("Wrapper with specific items related").locatedBy("//p[@class='ProductPrice_container__price__LS1Td']");
    public static final Target MESSAGE_MORE_PRODUCTS = Target.the("Message about no available item").locatedBy("//div[@role='status']/button/p");
    public static final Target NEXT_PAGE_BUTTON = Target.the("Message about no available item").locatedBy("//span[@data-fs-pagination-seguiente='true']");
    public static final Target MESSAGE_PAYLESS = Target.the("Message about no available item").locatedBy("//*[@id='wps-overlay-close-button']");


}
