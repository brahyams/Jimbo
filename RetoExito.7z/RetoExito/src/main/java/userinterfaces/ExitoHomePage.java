package userinterfaces;
import net.serenitybdd.annotations.DefaultUrl;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

@DefaultUrl("https://www.exito.com/")
public class ExitoHomePage extends PageObject {
    public static final Target MODAL_SECTION = Target.the("Element displayed the fisrt time when you access to Exito page").locatedBy("//*[@data-wps-popup-content]/div[@id='wps-overlay-close-button']");
    public static final Target SHOW_SIDEBAR_BUTTON = Target.the("Element that handle the open-close sidebar").locatedBy("//*[@data-fs-menu-icon-container='true']");
    public static final Target SIDEBAR_CONTAINER = Target.the("Wrapper with the news, categories and services availables").locatedBy("//*[@class='exito-category-menu-3-x-containerDrawer']");
    public static final Target TECHNOLOGY_SECTION = Target.the("Element to acces a specific categorie").locatedBy("//ul/section[2]/div/li[1]");
    public static final Target FOOD_SECTION = Target.the("Element to acces a specific categorie").locatedBy("//li[@id='undefined-nivel2-Mercado']");
    public static final Target TECHNOLOGY_SUBCATEGORIE_SECTION = Target.the("Element to choose a specific subcategorie").locatedBy("//*[@id='column-3']/li[1]/ul/li[1]/a");
    public static final Target RICE_SUBCATEGORIE_SECTION = Target.the("Element to choose a specific subcategorie").locatedBy("//a[@id='Categorías-nivel3-Arroz, granos y pastas']");
    public static final Target CLOSE_DELIVERY_OPTION = Target.the("Element to choose a specific subcategorie").locatedBy("//*[@class='exito-geolocation-3-x-cursorPointer']");




}
