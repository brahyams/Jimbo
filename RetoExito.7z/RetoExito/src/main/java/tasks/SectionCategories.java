package tasks;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;

import static userinterfaces.ExitoHomePage.*;
public class SectionCategories implements Task {

    public static SectionCategories isSelected(){
        return Tasks.instrumented(SectionCategories.class);
    }
    @Override
    public <T extends Actor> void performAs(T actor) {
        /*if (MODAL_SECTION.isVisibleFor(actor)){
            Click.on(MODAL_SECTION);
        }*/
        actor.attemptsTo(


                Click.on(SHOW_SIDEBAR_BUTTON),

                Click.on(TECHNOLOGY_SECTION),

                Click.on(TECHNOLOGY_SUBCATEGORIE_SECTION)
        );

    }
}
