package tasks;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;
import static userinterfaces.ExitoHomePage.*;
public class GoToFoodSection implements Task {
    public static GoToFoodSection isSelected(){
        return Tasks.instrumented(GoToFoodSection.class);
    }
    @Override
    public <T extends Actor> void performAs(T actor) {

        if (MODAL_SECTION.isVisibleFor(actor)){
            Click.on(MODAL_SECTION);
        }

            actor.attemptsTo(
                    Click.on(SHOW_SIDEBAR_BUTTON),
                    WaitUntil.the(SIDEBAR_CONTAINER, WebElementStateMatchers.isVisible()).forNoMoreThan(5000).milliseconds(),
                    Click.on(FOOD_SECTION),
                    Click.on(RICE_SUBCATEGORIE_SECTION),
                    WaitUntil.the(CLOSE_DELIVERY_OPTION, WebElementStateMatchers.isVisible()).forNoMoreThan(5000).milliseconds(),
                    Click.on(CLOSE_DELIVERY_OPTION)
            );
        }

}
