package tasks;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.SendKeys;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;

import static userinterfaces.CartGatewayPage.*;
import static userinterfaces.SubcategorieItems.GO_TO_CART_SECTION;

public class GoToCartSection implements Task {
    public static GoToCartSection andVerifyPurchaseItems(){
        return Tasks.instrumented(GoToCartSection.class);
    }
    @Override
    public <T extends Actor> void performAs(T actor) {

        actor.attemptsTo(
                WaitUntil.the(GO_TO_CART_SECTION, WebElementStateMatchers.isVisible()).forNoMoreThan(5000).milliseconds(),
                Click.on(GO_TO_CART_SECTION)
                /*WaitUntil.the(GO_TO_PAY, WebElementStateMatchers.isVisible()).forNoMoreThan(5000).milliseconds(),
                WaitUntil.the(TITLE_FORM, WebElementStateMatchers.isVisible()).forNoMoreThan(5000).milliseconds(),
                SendKeys.of("luisalbertoms0312@gmail.com").into(EMAIL_SECTION),
                Click.on(CONFIRM_BUTTON)*/

                );
    }
}
