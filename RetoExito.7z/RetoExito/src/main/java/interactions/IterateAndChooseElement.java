package interactions;
import net.serenitybdd.core.pages.ClearContents;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.*;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.Wait;
import net.serenitybdd.screenplay.waits.WaitUntil;
import org.openqa.selenium.WebElement;
import userinterfaces.SubcategorieItems;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import static userinterfaces.SubcategorieItems.*;
public class IterateAndChooseElement implements Interaction {
    private final Random random = new Random();
    public static IterateAndChooseElement enListaDeCompra() {
        return Tasks.instrumented(IterateAndChooseElement.class);
    }
    @Override
    public <T extends Actor> void performAs(T actor) {


        List<Integer> usedPositions = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            List<WebElementFacade> listItems = CONTAINER_OF_ITEMS.resolveAllFor(actor);
            List<WebElementFacade> price = SubcategorieItems.ITEM_PRICE.resolveAllFor(actor);
            List<WebElementFacade> purchaseButton = PURCHASE_BUTTON.resolveAllFor(actor);
            List<WebElementFacade> itemsSelected = SELECTED_ITEM.resolveAllFor(actor);



            if (!purchaseButton.isEmpty()) {


                int randomPositionSelected;
                int elementsChecked = itemsSelected.size();
                System.out.println("Elements previusly checked were : " + elementsChecked);
                do {
                    List<WebElementFacade> sizeProgram = purchaseButton;
                    int itemsAvailables = sizeProgram.size();
                    System.out.println("The current amount of items is : "  + itemsAvailables);

                    randomPositionSelected = generateRandomPosition(sizeProgram.size()-1);
                    System.out.println("The random position generated was :" + randomPositionSelected);
                } while (usedPositions.contains(randomPositionSelected));
                usedPositions.add(randomPositionSelected);

                WebElementFacade randomPositionPrice = price.get(randomPositionSelected);
                String priceElement = randomPositionPrice.getText();

                WebElementFacade randomPositionElement = purchaseButton.get(randomPositionSelected);

                WebElementFacade randomPositionName = listItems.get(randomPositionSelected);
                String nameElement = randomPositionName.getText();

                System.out.println("The item selected was : " + nameElement);
                actor.remember("nameProduct", nameElement);
                actor.remember("positionClicked" , randomPositionElement);
                actor.remember("Price item", priceElement);
                elementsChecked++;
                System.out.println("Elements checked are : " + elementsChecked);



                actor.attemptsTo(
                Scroll.to(randomPositionPrice).andAlignToBottom(),
                Click.on(randomPositionElement),
                        AmountOfPurchase.generateRange(1,5)
                        //Click.on(NEXT_PAGE_BUTTON)




                //AmountOfPurchase.generateRange(1,10)

                            );
            } else {
                System.out.println("No hay botones de compra en la página");
            }

        }
    }
    private int generateRandomPosition(int amountElements) {

        return random.nextInt(amountElements);
    }

}
