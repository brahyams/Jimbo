package interactions;
import models.ProductSelected;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;
import userinterfaces.SubcategorieItems;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import static userinterfaces.SubcategorieItems.*;
public class AmountOfPurchase implements Interaction {
    private int initial;
    private int last;
    public AmountOfPurchase(int inital, int last) {
        this.initial = inital;
        this.last = last;
    }
    public static AmountOfPurchase generateRange(int initial, int last){
        return Tasks.instrumented(AmountOfPurchase.class, initial, last);
    }
    @Override
    public <T extends Actor> void performAs(T actor) {


        WaitUntil.the(ADD_ITEMS_GENERAL, WebElementStateMatchers.isCurrentlyVisible()).forNoMoreThan(10000).milliseconds();
        List<WebElementFacade> element = SubcategorieItems.ADD_ITEMS_GENERAL.resolveAllFor(actor);



        if (element.isEmpty()) {

            System.out.println("No hay elementos disponibles para clickear");

        } else {

            List<Integer> usedPositions = new ArrayList<>();
            List<ProductSelected> productSelectedList = new ArrayList<>();

            int elementToAdd;
            elementToAdd = (element.size());
            usedPositions.add(elementToAdd);
            WebElementFacade positionToClick = element.get(elementToAdd - 1);
            System.out.println("Elemento a dar clic es el de la posición: " + elementToAdd);


            int randomSize = generateRandomSize();

            for (int j = 0; j < randomSize; j++) {

                positionToClick.click();

                actor.remember("amount of clicks", j + 1);  // Recordar la cantidad actual de clics


                if (MESSAGE_MORE_PRODUCTS.isVisibleFor(actor)) {
                    System.out.println("There is not more items in the stock");
                    break;
                }


                System.out.println("La cantidad de clicks aleatorios será: " + randomSize);

                WaitUntil.the(REDUCE_ITEMS_GENERAL, WebElementStateMatchers.isCurrentlyVisible()).forNoMoreThan(5000).milliseconds();
            }






            int clicks = actor.recall("amount of clicks");
            int amountOfItems = clicks + 1;
            System.out.println("The amount of elements added were : " + amountOfItems);


            String itemValue = actor.recall("Price item");
            System.out.println(itemValue);
            String partsProductPrice = itemValue.replaceAll("\\.", "");
            String[] valuesSeparated = partsProductPrice.split(" ");
            String numericProductPrice = valuesSeparated[1];
            int numericValueProductPrice = Integer.parseInt((numericProductPrice));
            System.out.println("Price is " + numericValueProductPrice);


            int result = (amountOfItems * numericValueProductPrice);
            System.out.println(amountOfItems + " Items were added");
            System.out.println("The final price of the purchase is : " + result);

            int valueResult = result;
            actor.remember("totalNumericValueProductPrice", numericValueProductPrice);
            actor.remember("result", valueResult);
            actor.recall("nameProduct");
            String product = actor.recall("nameProduct");

            ProductSelected productSelected = new ProductSelected(product,numericValueProductPrice,valueResult);
            productSelectedList.add(productSelected);


            actor.remember("productInfoList", productSelectedList);


            System.out.println("Go to the following page");
            WaitUntil.the(CONTAINER_OF_ITEMS, WebElementStateMatchers.isCurrentlyVisible()).forNoMoreThan(5000).milliseconds();


        }

        }


            private int generateRandomSize() {
            Random random = new Random();
            return random.nextInt(last - initial + 1) + initial;
        }
    }