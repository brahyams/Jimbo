package interactions;
import models.ProductShowedCart;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;

import java.util.ArrayList;
import java.util.List;

import static userinterfaces.CartGatewayPage.*;
import static userinterfaces.SubcategorieItems.GO_TO_CART_SECTION;

public class CartSection implements Interaction {
    public static CartSection validateElements(){
        return Tasks.instrumented(CartSection.class);
    }
    @Override
    public <T extends Actor> void performAs(T actor) {

        List<ProductShowedCart> shoppingCartItems = new ArrayList<>();

        List<WebElementFacade> listItemsCart = ITEMS_CART.resolveAllFor(actor);
        List<WebElementFacade> listValueItemsCart = VALUE_ITEMS_CART.resolveAllFor(actor);
        List<WebElementFacade> listUnitItemsCart = UNITS_ITEMS_CART.resolveAllFor(actor);
        if(!listItemsCart.isEmpty() && listItemsCart.size() == listValueItemsCart.size() && listItemsCart.size() == listUnitItemsCart.size())
        {
            for (int i = 0; i < listItemsCart.size(); i++) {
                String itemText = listItemsCart.get(i).getText();
                String valueItem = listValueItemsCart.get(i).getText();
                String unitAdded = listUnitItemsCart.get(i).getText();


                ProductShowedCart cartItem = new ProductShowedCart(itemText, valueItem, unitAdded);
                shoppingCartItems.add(cartItem);


                System.out.println("In the cart are the following item: " + itemText);
                System.out.println("Value: " + valueItem);
                System.out.println("Units added: " + unitAdded);
            }
        }
        actor.remember("List from Cart Section", shoppingCartItems);
    }
}
