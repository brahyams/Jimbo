package questions;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;
import static userinterfaces.CartGatewayPage.PRICE_TOTAL;

public class CartValidationTotalToPay  implements Question<Boolean> {
    public static CartValidationTotalToPay isEquals(){
        return new CartValidationTotalToPay();
    }
    @Override
    public Boolean answeredBy(Actor actor) {
        String totalToPayRecall = actor.recall("result");
        String totalToPay = Text.of(PRICE_TOTAL).asString().answeredBy(actor);
        String partsTotal = totalToPay.replaceAll("\\.", "");
        String[] valuesSeparated = partsTotal.split(" ");
        String totalPrice = valuesSeparated[1];

        System.out.println(totalPrice);
        System.out.println(totalToPayRecall);
        return totalToPayRecall.equals(totalPrice);
    }
}
