package questions;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ValidateSelectedProducts implements Question<Boolean> {
    String actualProductList;
    String currentListCart;

    public ValidateSelectedProducts(String actualProductList, String currentListCart) {
        this.actualProductList = actualProductList;
        this.currentListCart = currentListCart;
    }
    public ValidateSelectedProducts() {

    }
    public static ValidateSelectedProducts isCurrentlyExcatly(){
        return new ValidateSelectedProducts();

    }
    @Override
    public Boolean answeredBy(Actor actor) {

        String actualProductList = actor.recall("productList");

        String currentListCart = actor.recall("List from Cart Section");
        return actualProductList.equals(currentListCart);
    }

}
