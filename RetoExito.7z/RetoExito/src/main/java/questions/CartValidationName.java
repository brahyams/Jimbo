package questions;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;
import static userinterfaces.CartGatewayPage.PRODUCT_NAME;

public class CartValidationName implements Question<Boolean> {
    public static CartValidationName isEquals(){
    return new CartValidationName();
    }
    @Override
    public Boolean answeredBy(Actor actor) {
        String ProductChoosen = actor.recall("nameProduct");
        String name = Text.of(PRODUCT_NAME).asString().answeredBy(actor);
        System.out.println(ProductChoosen);
        System.out.println(name);
        return ProductChoosen.equals(name);


    }

  }
