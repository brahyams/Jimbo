package models;

public class ProductShowedCart {
    private final String itemText;
    private final String valueItem;
    private final String unitAdded;

    public ProductShowedCart(String itemText, String valueItem, String unitAdded) {
        this.itemText = itemText;
        this.valueItem = valueItem;
        this.unitAdded = unitAdded;
    }

    public String getItemText() {
        return itemText;
    }

    public String getValueItem() {
        return valueItem;
    }

    public String getUnitAdded() {
        return unitAdded;
    }
}
