package models;

public class ProductSelected {
    int resultOfPurchase;
    String nameProduct;
    int amountOfProducts;

    public ProductSelected(String nameProduct, int amountOfProducts, int resultOfPurchase) {
        this.nameProduct = nameProduct;
        this.amountOfProducts = amountOfProducts;
        this.resultOfPurchase = resultOfPurchase;
    }

    public int getResultOfPurchase() {
        return resultOfPurchase;
    }

    public String getNameProduct() {
        return nameProduct;
    }

    public int getAmountOfProducts() {
        return amountOfProducts;
    }


}