package co.com.choucair.certification.exito.stepdefinitions;
import interactions.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import models.ProductSelected;
import net.serenitybdd.screenplay.Actor;
import questions.ValidateSelectedProducts;
import tasks.GoToCartSection;
import tasks.NavigateTo;
import tasks.SectionCategories;

import java.util.List;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;

public class FlowExitoStepDefinition {
    @Given("{actor} is on Exito main page")
    public void that_an_user_is_on_Exito_main_page(Actor actor){
        actor.wasAbleTo(NavigateTo.theMainPage());
    }

    @When("{actor} go to a specfiic categorie section")
    public void he_go_to_a_specfiic_categories_section(Actor actor){
        actor.attemptsTo(
                SectionCategories.isSelected()

        );
    }

    @And("{actor} add some articles in the cart")
    public void he_add_some_articles_in_the_cart(Actor actor){
        actor.attemptsTo(
         AmountOfPurchase.generateRange(1, 5)

        );


        }

    @And("{actor} choose the items")
    public void he_choose_the_items(Actor actor){
        actor.attemptsTo(
                IterateAndChooseElement.enListaDeCompra()
                         );


    }


    @And("{actor} go to cart section")
    public void he_go_to_cart_section(Actor actor){
        actor.attemptsTo(
                GoToCartSection.andVerifyPurchaseItems(),
                CartSection.validateElements()


        );



    }
     @Then("{actor} validates the items information")
    public void he_validates_the_items(Actor actor){

        actor.should(
                String.valueOf(ValidateSelectedProducts.isCurrentlyExcatly())
                //seeThat(CartValidationName.isEquals()),


                //seeThat(CartValidationTotalToPay.isEquals())
        );

    }

}


