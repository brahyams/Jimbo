# Introduction 
TODO: Select different items to validate the values at the end of the process

# Getting Started
TODO: Setup the scenarios acording a user history to describe the end to end flow of the aplication using the following:
1.	Java JDK 11+
2.	Gradle
3.	Choucair libraries and specefic libraries or dependencies to build the artifact 
4.	CI/CD configurations

# Build and Test
TODO: Creation of a CI/CD and RM process to build the artifact, check the code and run the escenarios and verify the test results 

